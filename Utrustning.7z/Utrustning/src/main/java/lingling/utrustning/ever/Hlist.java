package lingling.utrustning.ever;

import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;

import java.lang.reflect.Field;
import java.nio.file.Path;

public class Hlist implements UpdateListener{
//    private final EnabledHacksFile EHF;
    private final EventManger eventManger =
            FFFClient.INSTANCE.getEventManger();

    public Hlist(Path EHF)
    {
//        this.EHF = new EnabledHacksFile(EHF);

        try
        {
            for(Field field : Hlist.class.getDeclaredFields())
            {
                if(!field.getName().endsWith("H")) {
                    continue;
                }

//                Hack hack = (Hack)field.get(this);
//                hax.put(hack.getName(), hack);
            }

        }catch(Exception e)
        {
            String message = "Initializing Wurst hacks";
            CrashReport report = CrashReport.create(e, message);
            throw new CrashException(report);
        }

        eventManger.add(UpdateListener.class, this);
    }

    @Override
    public void onUpdate() {

    }
//    public void saveEnabledHax()
//    {
//        EHF.save(this);
//    }
}
