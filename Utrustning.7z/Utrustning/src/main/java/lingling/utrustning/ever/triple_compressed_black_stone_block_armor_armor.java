package lingling.utrustning.ever;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class triple_compressed_black_stone_block_armor_armor extends ArmorItem {
    public triple_compressed_black_stone_block_armor_armor(ArmorMaterial material, EquipmentSlot slot, Settings settings) {
        super(material, slot, settings);
    }
    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.HEAD).getItem() == RegItem.TBBB_HE ||
                        livingEntity.getEquippedStack(EquipmentSlot.CHEST).getItem() == RegItem.TBBB_CH ||
                        livingEntity.getEquippedStack(EquipmentSlot.LEGS).getItem() == RegItem.TBBB_LE ||
                        livingEntity.getEquippedStack(EquipmentSlot.FEET).getItem() == RegItem.TBBB_BO
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 240,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 240,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 240,0, false, false, false));
        }
    }
}
