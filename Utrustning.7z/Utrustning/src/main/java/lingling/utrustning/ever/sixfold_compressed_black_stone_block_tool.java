package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class sixfold_compressed_black_stone_block_tool implements ToolMaterial {

    public static final sixfold_compressed_black_stone_block_tool INSTANCE = new sixfold_compressed_black_stone_block_tool();

    @Override
    public int getDurability() {
        return 50000000;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 123321.0F;
    }

    @Override
    public float getAttackDamage() {
        return 32767.0F;
    }

    @Override
    public int getMiningLevel() {
        return 255;
    }

    @Override
    public int getEnchantability() {
        return 32767;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.SBB_BLOCK);
    }
}