package lingling.utrustning.ever;

import net.minecraft.block.BlockState;
import net.minecraft.block.CobwebBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.ArrayList;

public class sixfold_compressed_black_stone_block_sword extends SwordItem {
    public sixfold_compressed_black_stone_block_sword(ToolMaterial toolMaterial, int attackDamage, float attackSpeed, Settings settings) {
        super(toolMaterial, attackDamage, attackSpeed, settings);
    }
    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.MAINHAND).getItem() == UtrustningMod.SBBB_W
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 1200,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 1200,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 1200,127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1200,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 1200,127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 1200,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 1200,127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.CONDUIT_POWER, 1200,127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, 1200,127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 1200,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 1200,3, false, false, false));
        }
    }
    private World world;
    private final BlockPos[] poses = Utils.poses_of_all_directions;
    private final ArrayList<BlockPos> poses1 = new ArrayList<>();

    private int mine_deep(BlockPos pos, BlockState state) {
        int cnt = 0;
        world.breakBlock(pos, true);
        for (BlockPos p : poses) {
            BlockPos p1 = pos.add(p);
            if (world.getBlockState(p1) == state) {
                cnt += mine_deep(p1, state);
            }
        }
        return ++cnt;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        int r = 4;
        Utils.breakBlocks(world, user.getBlockPos().up(r), r);
        return TypedActionResult.success(stack);
    }
    private void mine_wide(BlockPos pos_o, BlockState state) {
        poses1.add(pos_o);
        for (BlockPos pos : poses1) {
            world.breakBlock(pos, true);
            for (BlockPos p : poses) {
                BlockPos p1 = pos.add(p);
                if (world.getBlockState(p1) == state) {
                    poses1.add(p1);
                }
            }
        }
    }
    @Override
    public boolean postMine(ItemStack stack, World world, BlockState state, BlockPos pos, LivingEntity miner) {
        this.world = world;
        if (state.getBlock() instanceof CobwebBlock) {
            stack.damage(mine_deep(pos, state), miner, e ->
                    e.sendEquipmentBreakStatus(EquipmentSlot.MAINHAND));
////            mine_wide(pos, state);
        }
//        ItemEntity itemEntity =  new ItemEntity(world, pos.getX(), pos.getY(), pos.getZ(), state.getDroppedStacks());
        return super.postMine(stack, world, state, pos, miner);
    }
}
