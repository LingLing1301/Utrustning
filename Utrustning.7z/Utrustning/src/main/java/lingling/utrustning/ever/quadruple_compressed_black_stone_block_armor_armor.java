package lingling.utrustning.ever;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class quadruple_compressed_black_stone_block_armor_armor extends ArmorItem {
    public quadruple_compressed_black_stone_block_armor_armor(ArmorMaterial material, EquipmentSlot slot, Settings settings) {
        super(material, slot, settings);
    }
    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.HEAD).getItem() == RegItem.QBBB_HE ||
                        livingEntity.getEquippedStack(EquipmentSlot.CHEST).getItem() == RegItem.QBBB_CH ||
                        livingEntity.getEquippedStack(EquipmentSlot.LEGS).getItem() == RegItem.QBBB_LE ||
                        livingEntity.getEquippedStack(EquipmentSlot.FEET).getItem() == RegItem.QBBB_BO
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 360,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 360,5, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 360,2, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 360,5, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 360,2, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 360,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 360,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.CONDUIT_POWER, 360,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, 360,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 360,0, false, false, false));
        }
    }
}
