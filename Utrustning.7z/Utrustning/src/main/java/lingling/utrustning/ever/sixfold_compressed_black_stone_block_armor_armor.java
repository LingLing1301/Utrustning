package lingling.utrustning.ever;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.stat.Stats;
import net.minecraft.world.GameMode;
import net.minecraft.world.World;
import lingling.utrustning.ever.HHH;

import java.util.UUID;

import static lingling.utrustning.ever.F.EVENTS;
import static lingling.utrustning.ever.F.MC;

public class sixfold_compressed_black_stone_block_armor_armor extends ArmorItem implements UpdateListener {
    public sixfold_compressed_black_stone_block_armor_armor(ArmorMaterial material, EquipmentSlot slot, Settings settings) {
        super(material, slot, settings);
    }
    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.HEAD).getItem() == RegItem.SBBB_HE ||
                        livingEntity.getEquippedStack(EquipmentSlot.CHEST).getItem() == RegItem.SBBB_CH ||
                        livingEntity.getEquippedStack(EquipmentSlot.LEGS).getItem() == RegItem.SBBB_LE ||
                        livingEntity.getEquippedStack(EquipmentSlot.FEET).getItem() == RegItem.SBBB_BO
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 1200, 0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 1200, 3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 1200, 127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 1200, 3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 1200, 127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 1200, 21, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 1200, 127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.CONDUIT_POWER, 1200, 127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, 1200, 127, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 1200, 1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 1200, 5, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 1200, 1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 1200, 5, false, false, false));
        }
    }
//    protected static final FFFClient W = FFFClient.INSTANCE;
//    protected static final EventManger EVENTS = W.getEventManger();
//    public final void setEnabled(boolean enabled)
//    {
//        if(enabled) {
//            onEnable();
//        }
//    }
//    public void onEnable()
//    {
//        EVENTS.add(UpdateListener.class, this);
//    }



//    public void onDisable()
//    {
//
//        ClientPlayerEntity player = MinecraftClient.getInstance().player;
//        PlayerAbilities abilities = player.getAbilities();
//
//        boolean creative = player.isCreative();
//        abilities.flying = creative && !player.isOnGround();
//        abilities.allowFlying = creative;
//
//    }
//    @Override
//    public void onUpdate() {
//        MinecraftClient.getInstance().player.getAbilities().allowFlying = true;
//    }


    public void onEnable()
    {
        EVENTS.add(UpdateListener.class, this);
    }

    @Override
    public void onUpdate()
    {
        ClientPlayerEntity player = MC.player;

        if(player.horizontalCollision || player.isSneaking()) {
            return;
        }

        if(player.isInsideWaterOrBubbleColumn() || player.isSubmergedInWater()) {
            return;
        }

        if(player.forwardSpeed > 0) {
            player.setSprinting(true);
        }

    }
}
