package lingling.utrustning.ever;

import com.ibm.icu.impl.duration.impl.Utils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import org.jetbrains.annotations.Nullable;

public class black_stone extends Item {
    public black_stone(Settings settings) {
        super(settings);
    }
    // Detect worn items and hand-held items and give potion effects。
//    @Override
//    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
//        LivingEntity livingEntity = (LivingEntity)entity;
//        if(
//               // livingEntity.getEquippedStack(EquipmentSlot.CHEST).getItem() == RegItem.B_CH &&
//                        livingEntity.getEquippedStack(EquipmentSlot.MAINHAND).getItem() == RegItem.B_CH
//                ) {
//            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 120,0, true, false, true));
//        }
//        }

    }
