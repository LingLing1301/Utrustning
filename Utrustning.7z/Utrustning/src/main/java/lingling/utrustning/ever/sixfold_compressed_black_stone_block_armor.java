package lingling.utrustning.ever;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public class sixfold_compressed_black_stone_block_armor implements ArmorMaterial {
    private static final int[] BASE_DURABILITY = new int[] {23, 25, 26, 21};
    private static final int[] PROTECTION_VALUES = new int[] {1500, 1580, 1600, 1500};
    @Override
    public int getDurability(EquipmentSlot slot) {
        return BASE_DURABILITY[slot.getEntitySlotId()] * 1000000;
    }

    @Override
    public int getProtectionAmount(EquipmentSlot slot) {
        return PROTECTION_VALUES[slot.getEntitySlotId()];
    }

    @Override
    public int getEnchantability() {
        return 32767;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ITEM_ARMOR_EQUIP_CHAIN;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.SBB_BLOCK);
    }

    @Override
    public String getName() {
        return "sixfold_compressed_black_stone_block";
    }

    @Override
    public float getToughness() {
        return 5600.0F;
    }

    @Override
    public float getKnockbackResistance() {
        return 3850.0F;
    }

}
