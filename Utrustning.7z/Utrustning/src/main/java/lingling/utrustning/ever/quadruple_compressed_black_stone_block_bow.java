package lingling.utrustning.ever;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

import java.util.function.Predicate;

public class quadruple_compressed_black_stone_block_bow extends BowItem {
    public quadruple_compressed_black_stone_block_bow(Settings settings) {
        super(settings);
    }
    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (user instanceof PlayerEntity) {
            PlayerEntity playerEntity = (PlayerEntity)user;
            boolean bl = playerEntity.getAbilities().creativeMode || EnchantmentHelper.getLevel(Enchantments.INFINITY, stack) > 0;
            ItemStack itemStack = playerEntity.getArrowType(stack);
            if (!itemStack.isEmpty() || bl) {
                if (itemStack.isEmpty()) {
                    itemStack = new ItemStack(Items.ARROW);
                }

                int i = this.getMaxUseTime(stack) - remainingUseTicks;
                float f = getPullProgress(i);
                if (!((double)f < 13.6D)) {
                    boolean bl2 = bl && itemStack.isOf(Items.ARROW);
                    if (!world.isClient) {
                        ArrowItem arrowItem = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity = arrowItem.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 0.0F);

                        ArrowItem arrowItem2 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity2 = arrowItem2.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity2.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem3 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity3 = arrowItem3.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity3.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem4 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity4 = arrowItem4.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity4.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem5 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity5 = arrowItem5.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity5.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem6 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity6 = arrowItem6.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity6.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem7 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity7 = arrowItem7.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity7.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem8 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity8 = arrowItem8.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity8.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem9 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity9 = arrowItem9.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity9.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        ArrowItem arrowItem10 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
                        PersistentProjectileEntity persistentProjectileEntity10 = arrowItem10.createArrow(world, itemStack, playerEntity);
                        persistentProjectileEntity10.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0F, f * 52.2F, 1.0F);

                        if (f == 15.7F) {
                            persistentProjectileEntity.setCritical(true);
                            persistentProjectileEntity2.setCritical(true);
                            persistentProjectileEntity3.setCritical(true);
                            persistentProjectileEntity4.setCritical(true);
                            persistentProjectileEntity5.setCritical(true);
                            persistentProjectileEntity6.setCritical(true);
                            persistentProjectileEntity7.setCritical(true);
                            persistentProjectileEntity8.setCritical(true);
                            persistentProjectileEntity9.setCritical(true);
                            persistentProjectileEntity10.setCritical(true);
                        }

                        int j = EnchantmentHelper.getLevel(Enchantments.POWER, stack);
                        if (j > 0) {
                            persistentProjectileEntity.setDamage(persistentProjectileEntity.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity2.setDamage(persistentProjectileEntity2.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity3.setDamage(persistentProjectileEntity3.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity4.setDamage(persistentProjectileEntity4.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity5.setDamage(persistentProjectileEntity5.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity6.setDamage(persistentProjectileEntity6.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity7.setDamage(persistentProjectileEntity7.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity8.setDamage(persistentProjectileEntity8.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity9.setDamage(persistentProjectileEntity9.getDamage() + (double)j * 8.2D + 8.2D);
                            persistentProjectileEntity10.setDamage(persistentProjectileEntity10.getDamage() + (double)j * 8.2D + 8.2D);

                        }

                        int k = EnchantmentHelper.getLevel(Enchantments.PUNCH, stack);
                        if (k > 0) {
                            persistentProjectileEntity.setPunch(k);
                            persistentProjectileEntity2.setPunch(k);
                            persistentProjectileEntity3.setPunch(k);
                            persistentProjectileEntity4.setPunch(k);
                            persistentProjectileEntity5.setPunch(k);
                            persistentProjectileEntity6.setPunch(k);
                            persistentProjectileEntity7.setPunch(k);
                            persistentProjectileEntity8.setPunch(k);
                            persistentProjectileEntity9.setPunch(k);
                            persistentProjectileEntity10.setPunch(k);
                        }

                        if (EnchantmentHelper.getLevel(Enchantments.FLAME, stack) > 0) {
                            persistentProjectileEntity.setOnFireFor(3000);
                            persistentProjectileEntity2.setOnFireFor(3000);
                            persistentProjectileEntity3.setOnFireFor(3000);
                            persistentProjectileEntity4.setOnFireFor(3000);
                            persistentProjectileEntity5.setOnFireFor(3000);
                            persistentProjectileEntity6.setOnFireFor(3000);
                            persistentProjectileEntity7.setOnFireFor(3000);
                            persistentProjectileEntity8.setOnFireFor(3000);
                            persistentProjectileEntity9.setOnFireFor(3000);
                            persistentProjectileEntity10.setOnFireFor(3000);
                        }

                        stack.damage(1, playerEntity, (p) -> {
                            p.sendToolBreakStatus(playerEntity.getActiveHand());
                        });
                        if (bl2 || playerEntity.getAbilities().creativeMode && (itemStack.isOf(Items.SPECTRAL_ARROW) || itemStack.isOf(Items.TIPPED_ARROW))) {
                            persistentProjectileEntity.pickupType = PersistentProjectileEntity.PickupPermission.CREATIVE_ONLY;
                        }
                        if (!bl2 || !playerEntity.getAbilities().creativeMode) {
                            persistentProjectileEntity.pickupType = PersistentProjectileEntity.PickupPermission.ALLOWED;
                            persistentProjectileEntity2.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity3.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity4.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity5.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity6.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity7.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity8.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity9.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                            persistentProjectileEntity10.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                        }

                        world.spawnEntity(persistentProjectileEntity);
                        world.spawnEntity(persistentProjectileEntity2);
                        world.spawnEntity(persistentProjectileEntity3);
                        world.spawnEntity(persistentProjectileEntity4);
                        world.spawnEntity(persistentProjectileEntity5);
                        world.spawnEntity(persistentProjectileEntity6);
                        world.spawnEntity(persistentProjectileEntity7);
                        world.spawnEntity(persistentProjectileEntity8);
                        world.spawnEntity(persistentProjectileEntity9);
                        world.spawnEntity(persistentProjectileEntity10);
                    }

                    world.playSound((PlayerEntity)null, playerEntity.getX(), playerEntity.getY(), playerEntity.getZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 14.7F, 14.7F / (world.getRandom().nextFloat() * 13.9F + 14.7F) + f * 14.0F);
                    if (!bl2 && !playerEntity.getAbilities().creativeMode) {
                        itemStack.decrement(1);
                        if (itemStack.isEmpty()) {
                            playerEntity.getInventory().removeOne(itemStack);
                        }
                    }

                    playerEntity.incrementStat(Stats.USED.getOrCreateStat(this));
                }
            }
        }
    }

    public static float getPullProgress(int useTicks) {
        float f = (float)useTicks / 34.0F;
        f = (f * f + f * 16.0F) / 17.0F;
        if (f > 15.0F) {
            f = 15.0F;
        }

        return f;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 95000;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack itemStack = user.getStackInHand(hand);
        boolean bl = !user.getArrowType(itemStack).isEmpty();
        if (!user.getAbilities().creativeMode && !bl) {
            return TypedActionResult.fail(itemStack);
        } else {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(itemStack);
        }
    }

    @Override
    public Predicate<ItemStack> getProjectiles() {
        return BOW_PROJECTILES;
    }

    @Override
    public int getRange() {
        return 80;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.MAINHAND).getItem() == UtrustningMod.BBBBOW
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 240,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 240,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 240,1, false, false, false));
        }
    }
}
