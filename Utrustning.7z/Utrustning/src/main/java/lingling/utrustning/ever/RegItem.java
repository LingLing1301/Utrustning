package lingling.utrustning.ever;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class RegItem {
    public static final ArmorMaterial black_stone_armor = new black_stone_armor();
    public static final Item B_HE = new ArmorItem(black_stone_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item B_CH = new ArmorItem(black_stone_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item B_LE = new ArmorItem(black_stone_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item B_BO = new ArmorItem(black_stone_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial black_block_armor = new black_block_armor();
    public static final Item BB_HE = new ArmorItem(black_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BB_CH = new ArmorItem(black_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BB_LE = new ArmorItem(black_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BB_BO = new ArmorItem(black_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial compression_black_block_armor = new compression_black_block_armor();
    public static final Item BBB_HE = new compression_black_block_armor_armor(compression_black_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BBB_CH = new compression_black_block_armor_armor(compression_black_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BBB_LE = new compression_black_block_armor_armor(compression_black_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item BBB_BO = new compression_black_block_armor_armor(compression_black_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial double_compressed_black_stone_block_armor = new double_compressed_black_stone_block_armor();
    public static final Item DBBB_HE = new double_compressed_black_stone_block_armor_armor(double_compressed_black_stone_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item DBBB_CH = new double_compressed_black_stone_block_armor_armor(double_compressed_black_stone_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item DBBB_LE = new double_compressed_black_stone_block_armor_armor(double_compressed_black_stone_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item DBBB_BO = new double_compressed_black_stone_block_armor_armor(double_compressed_black_stone_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial triple_compressed_black_stone_block_armor = new triple_compressed_black_stone_block_armor();
    public static final Item TBBB_HE = new triple_compressed_black_stone_block_armor_armor(triple_compressed_black_stone_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item TBBB_CH = new triple_compressed_black_stone_block_armor_armor(triple_compressed_black_stone_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item TBBB_LE = new triple_compressed_black_stone_block_armor_armor(triple_compressed_black_stone_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item TBBB_BO = new triple_compressed_black_stone_block_armor_armor(triple_compressed_black_stone_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial quadruple_compressed_black_stone_block_armor = new quadruple_compressed_black_stone_block_armor();
    public static final Item QBBB_HE = new quadruple_compressed_black_stone_block_armor_armor(quadruple_compressed_black_stone_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item QBBB_CH = new quadruple_compressed_black_stone_block_armor_armor(quadruple_compressed_black_stone_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item QBBB_LE = new quadruple_compressed_black_stone_block_armor_armor(quadruple_compressed_black_stone_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item QBBB_BO = new quadruple_compressed_black_stone_block_armor_armor(quadruple_compressed_black_stone_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial five_compressed_black_stone_block_armor = new five_compressed_black_stone_block_armor();
    public static final Item FBBB_HE = new five_compressed_black_stone_block_armor_armor(five_compressed_black_stone_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item FBBB_CH = new five_compressed_black_stone_block_armor_armor(five_compressed_black_stone_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item FBBB_LE = new five_compressed_black_stone_block_armor_armor(five_compressed_black_stone_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item FBBB_BO = new five_compressed_black_stone_block_armor_armor(five_compressed_black_stone_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static final ArmorMaterial sixfold_compressed_black_stone_block_armor = new sixfold_compressed_black_stone_block_armor();
    public static final Item SBBB_HE = new sixfold_compressed_black_stone_block_armor_armor(sixfold_compressed_black_stone_block_armor, EquipmentSlot.HEAD, new Item.Settings().group(UtrustningMod.BG));
    public static final Item SBBB_CH = new sixfold_compressed_black_stone_block_armor_armor(sixfold_compressed_black_stone_block_armor, EquipmentSlot.CHEST, new Item.Settings().group(UtrustningMod.BG));
    public static final Item SBBB_LE = new sixfold_compressed_black_stone_block_armor_armor(sixfold_compressed_black_stone_block_armor, EquipmentSlot.LEGS, new Item.Settings().group(UtrustningMod.BG));
    public static final Item SBBB_BO = new sixfold_compressed_black_stone_block_armor_armor(sixfold_compressed_black_stone_block_armor, EquipmentSlot.FEET, new Item.Settings().group(UtrustningMod.BG));

    public static void register() {
        Registry.register(Registry.ITEM, new Identifier("p", "black_stone_helmet"), B_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "black_stone_chestplate"), B_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "black_stone_leggings"), B_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "black_stone_boots"), B_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "black_block_helmet"), BB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "black_block_chestplate"), BB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "black_block_leggings"), BB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "black_block_boots"), BB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_helmet"), BBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_chestplate"), BBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_leggings"), BBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_boots"), BBB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_helmet"), DBBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_chestplate"), DBBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_leggings"), DBBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_boots"), DBBB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_helmet"), TBBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_chestplate"), TBBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_leggings"), TBBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_boots"), TBBB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_helmet"), QBBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_chestplate"), QBBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_leggings"), QBBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_boots"), QBBB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_helmet"), FBBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_chestplate"), FBBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_leggings"), FBBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_boots"), FBBB_BO);

        Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_helmet"), SBBB_HE);
        Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_chestplate"), SBBB_CH);
        Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_leggings"), SBBB_LE);
        Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_boots"), SBBB_BO);

    }
}

