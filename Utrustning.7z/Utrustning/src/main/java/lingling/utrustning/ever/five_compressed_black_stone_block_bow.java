package lingling.utrustning.ever;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

import java.util.function.Predicate;

public class five_compressed_black_stone_block_bow extends BowItem {
    public five_compressed_black_stone_block_bow(Settings settings) {
        super(settings);
    }
    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        boolean bl2;
        int i;
        float f;
        if (!(user instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity playerEntity = (PlayerEntity)user;
        boolean bl = playerEntity.getAbilities().creativeMode || EnchantmentHelper.getLevel(Enchantments.INFINITY, stack) > 0;
        ItemStack itemStack = playerEntity.getArrowType(stack);
        if (itemStack.isEmpty() && !bl) {
            return;
        }
        if (itemStack.isEmpty()) {
            itemStack = new ItemStack(Items.ARROW);
        }
        if ((double)(f = BowItem.getPullProgress(i = this.getMaxUseTime(stack) - remainingUseTicks)) < 0.1) {
            return;
        }
        boolean bl3 = bl2 = bl && itemStack.isOf(Items.ARROW);
        if (!world.isClient) {
            int k;
            int j;
            ArrowItem arrowItem = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity = arrowItem.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 0.0f);

            ArrowItem arrowItem2 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity2 = arrowItem2.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity2.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem3 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity3 = arrowItem3.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity3.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem4 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity4 = arrowItem4.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity4.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem5 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity5 = arrowItem5.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity5.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem6 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity6 = arrowItem6.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity6.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem7 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity7 = arrowItem7.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity7.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem8 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity8 = arrowItem8.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity8.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem9 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity9 = arrowItem9.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity9.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            ArrowItem arrowItem10 = (ArrowItem)(itemStack.getItem() instanceof ArrowItem ? itemStack.getItem() : Items.ARROW);
            PersistentProjectileEntity persistentProjectileEntity10 = arrowItem10.createArrow(world, itemStack, playerEntity);
            persistentProjectileEntity10.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 300.0f, 1.0f);

            if (f == 1.0f) {
                persistentProjectileEntity.setCritical(true);
                persistentProjectileEntity2.setCritical(true);
                persistentProjectileEntity3.setCritical(true);
                persistentProjectileEntity4.setCritical(true);
                persistentProjectileEntity5.setCritical(true);
                persistentProjectileEntity6.setCritical(true);
                persistentProjectileEntity7.setCritical(true);
                persistentProjectileEntity8.setCritical(true);
                persistentProjectileEntity9.setCritical(true);
                persistentProjectileEntity10.setCritical(true);
            }
            if ((j = EnchantmentHelper.getLevel(Enchantments.POWER, stack)) > 0) {
                persistentProjectileEntity.setDamage(persistentProjectileEntity.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity2.setDamage(persistentProjectileEntity2.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity3.setDamage(persistentProjectileEntity3.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity4.setDamage(persistentProjectileEntity4.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity5.setDamage(persistentProjectileEntity5.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity6.setDamage(persistentProjectileEntity6.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity7.setDamage(persistentProjectileEntity7.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity8.setDamage(persistentProjectileEntity8.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity9.setDamage(persistentProjectileEntity9.getDamage() + (double)j * 100.5 + 100.5);
                persistentProjectileEntity10.setDamage(persistentProjectileEntity10.getDamage() + (double)j * 100.5 + 100.5);
            }
            if ((k = EnchantmentHelper.getLevel(Enchantments.PUNCH, stack)) > 0) {
                persistentProjectileEntity.setPunch(k);
                persistentProjectileEntity2.setPunch(k);
                persistentProjectileEntity3.setPunch(k);
                persistentProjectileEntity4.setPunch(k);
                persistentProjectileEntity5.setPunch(k);
                persistentProjectileEntity6.setPunch(k);
                persistentProjectileEntity7.setPunch(k);
                persistentProjectileEntity8.setPunch(k);
                persistentProjectileEntity9.setPunch(k);
                persistentProjectileEntity10.setPunch(k);
            }
            if (EnchantmentHelper.getLevel(Enchantments.FLAME, stack) > 0) {
                persistentProjectileEntity.setOnFireFor(10000);
                persistentProjectileEntity2.setOnFireFor(10000);
                persistentProjectileEntity3.setOnFireFor(10000);
                persistentProjectileEntity4.setOnFireFor(10000);
                persistentProjectileEntity5.setOnFireFor(10000);
                persistentProjectileEntity6.setOnFireFor(10000);
                persistentProjectileEntity7.setOnFireFor(10000);
                persistentProjectileEntity8.setOnFireFor(10000);
                persistentProjectileEntity9.setOnFireFor(10000);
                persistentProjectileEntity10.setOnFireFor(10000);
            }
            stack.damage(10, playerEntity, p -> p.sendToolBreakStatus(playerEntity.getActiveHand()));
            if (bl2 || playerEntity.getAbilities().creativeMode && (itemStack.isOf(Items.SPECTRAL_ARROW) || itemStack.isOf(Items.TIPPED_ARROW))) {
                persistentProjectileEntity.pickupType = PersistentProjectileEntity.PickupPermission.CREATIVE_ONLY;
            }
            if (!bl2 || !playerEntity.getAbilities().creativeMode) {
                persistentProjectileEntity.pickupType = PersistentProjectileEntity.PickupPermission.ALLOWED;
                persistentProjectileEntity2.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity3.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity4.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity5.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity6.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity7.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity8.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity9.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
                persistentProjectileEntity10.pickupType = PersistentProjectileEntity.PickupPermission.DISALLOWED;
            }
            world.spawnEntity(persistentProjectileEntity);
            world.spawnEntity(persistentProjectileEntity2);
            world.spawnEntity(persistentProjectileEntity3);
            world.spawnEntity(persistentProjectileEntity4);
            world.spawnEntity(persistentProjectileEntity5);
            world.spawnEntity(persistentProjectileEntity6);
            world.spawnEntity(persistentProjectileEntity7);
            world.spawnEntity(persistentProjectileEntity8);
            world.spawnEntity(persistentProjectileEntity9);
            world.spawnEntity(persistentProjectileEntity10);
        }
        world.playSound(null, playerEntity.getX(), playerEntity.getY(), playerEntity.getZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 100.0f, 100.0f / (world.getRandom().nextFloat() * 100.4f + 100.2f) + f * 100.5f);
        if (!bl2 && !playerEntity.getAbilities().creativeMode) {
            itemStack.decrement(1);
            if (itemStack.isEmpty()) {
                playerEntity.getInventory().removeOne(itemStack);
            }
        }
        playerEntity.incrementStat(Stats.USED.getOrCreateStat(this));
    }

    public static float getPullProgress(int useTicks) {
        float f = (float)useTicks / 20.0f;
        if ((f = (f * f + f * 2.0f) / 3.0f) > 1.0f) {
            f = 1.0f;
        }
        return f;
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.BOW;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        boolean bl;
        ItemStack itemStack = user.getStackInHand(hand);
        boolean bl2 = bl = !user.getArrowType(itemStack).isEmpty();
        if (user.getAbilities().creativeMode || bl) {
            user.setCurrentHand(hand);
            return TypedActionResult.consume(itemStack);
        }
        return TypedActionResult.fail(itemStack);
    }

    @Override
    public Predicate<ItemStack> getProjectiles() {
        return BOW_PROJECTILES;
    }

    @Override
    public int getRange() {
        return 15;
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.MAINHAND).getItem() == UtrustningMod.FBBBBOW
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 720,0, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 720,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 720,3, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.SATURATION, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HERO_OF_THE_VILLAGE, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.CONDUIT_POWER, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.DOLPHINS_GRACE, 720,20, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 720,1, false, false, false));
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 720,1, false, false, false));
        }
    }
    @Override
    public boolean hasGlint(ItemStack stack) {
        return true;
    }
}
