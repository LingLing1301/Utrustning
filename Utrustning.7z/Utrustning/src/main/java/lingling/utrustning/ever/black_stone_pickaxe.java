package lingling.utrustning.ever;

import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ToolMaterial;

public class black_stone_pickaxe extends PickaxeItem {
    protected black_stone_pickaxe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
}
