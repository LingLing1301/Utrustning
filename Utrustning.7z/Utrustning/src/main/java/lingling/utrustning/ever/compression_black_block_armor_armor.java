package lingling.utrustning.ever;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class compression_black_block_armor_armor extends ArmorItem {
    public compression_black_block_armor_armor(ArmorMaterial material, EquipmentSlot slot, Settings settings) {
        super(material, slot, settings);
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        LivingEntity livingEntity = (LivingEntity)entity;
        if(
                livingEntity.getEquippedStack(EquipmentSlot.HEAD).getItem() == RegItem.BBB_HE ||
                livingEntity.getEquippedStack(EquipmentSlot.CHEST).getItem() == RegItem.BBB_CH ||
                livingEntity.getEquippedStack(EquipmentSlot.LEGS).getItem() == RegItem.BBB_LE ||
                livingEntity.getEquippedStack(EquipmentSlot.FEET).getItem() == RegItem.BBB_BO
        ) {
            livingEntity.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 120,1, false, false, false));
        }
    }
}
