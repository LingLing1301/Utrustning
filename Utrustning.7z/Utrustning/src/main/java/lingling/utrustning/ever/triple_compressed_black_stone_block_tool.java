package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class triple_compressed_black_stone_block_tool implements ToolMaterial {

    public static final triple_compressed_black_stone_block_tool INSTANCE = new triple_compressed_black_stone_block_tool();

    @Override
    public int getDurability() {
        return 233333;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 618.0F;
    }

    @Override
    public float getAttackDamage() {
        return 127.0F;
    }

    @Override
    public int getMiningLevel() {
        return 23;
    }

    @Override
    public int getEnchantability() {
        return 618;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.TBB_BLOCK);
    }
}