package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class quadruple_compressed_black_stone_block_tool implements ToolMaterial {

    public static final quadruple_compressed_black_stone_block_tool INSTANCE = new quadruple_compressed_black_stone_block_tool();

    @Override
    public int getDurability() {
        return 999999;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 4999.0F;
    }

    @Override
    public float getAttackDamage() {
        return 512.0F;
    }

    @Override
    public int getMiningLevel() {
        return 50;
    }

    @Override
    public int getEnchantability() {
        return 1314;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.QBB_BLOCK);
    }
}