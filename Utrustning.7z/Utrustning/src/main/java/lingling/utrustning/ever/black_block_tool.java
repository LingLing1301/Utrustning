package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class black_block_tool implements ToolMaterial {

    public static final black_block_tool INSTANCE = new black_block_tool();

    @Override
    public int getDurability() {
        return 8257;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 55.0F;
    }

    @Override
    public float getAttackDamage() {
        return 5.0F;
    }

    @Override
    public int getMiningLevel() {
        return 7;
    }

    @Override
    public int getEnchantability() {
        return 85;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.B_BLOCK);
    }
}