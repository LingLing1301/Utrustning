/*
 * Copyright (c) 2014-2022 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package lingling.utrustning.ever;


import java.util.Objects;

public abstract class HHH extends F
{
	private final String name;
	private final String description;
	private C category;
	
	private boolean enabled;
	private final boolean stateSaved =
		!getClass().isAnnotationPresent(DS.class);
	
	public HHH(String name)
	{
		this.name = Objects.requireNonNull(name);
		description = "description.wurst.hack." + name.toLowerCase();
	}
	

	public final String getName()
	{
		return name;
	}
	
	public String getRenderName()
	{
		return name;
	}

	@Override
	public final C getCategory()
	{
		return category;
	}
	
	public final void setCategory(C category)
	{
		this.category = category;
	}
	
	@Override
	public final boolean isEnabled()
	{
		return enabled;
	}
	
	public final void setEnabled(boolean enabled)
	{
		if(this.enabled == enabled) {
			return;
		}

//		if(enabled && tooManyHax.isEnabled() && tooManyHax.isBlocked(this))
//			return;
//
//		this.enabled = enabled;
		
//		if(!(this instanceof NavigatorHack || this instanceof ClickGuiHack))
//			WURST.getHud().getHackList().updateState(this);
		
		if(enabled) {
			onEnable();
		} else {
			onDisable();
		}
		
		if(stateSaved) {
		//	W.getHax().saveEnabledHax();
		}
	}
	
	@Override
	public final String getPrimaryAction()
	{
		return enabled ? "Disable" : "Enable";
	}
	
	@Override
	public final void doPrimaryAction()
	{
		setEnabled(!enabled);
	}
	
	public final boolean isStateSaved()
	{
		return stateSaved;
	}
	
	protected void onEnable()
	{
		
	}
	
	protected void onDisable()
	{
		
	}
}
