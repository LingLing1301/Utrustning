package lingling.utrustning.ever;
import java.util.EventListener;
public interface Listener extends EventListener
{

}
