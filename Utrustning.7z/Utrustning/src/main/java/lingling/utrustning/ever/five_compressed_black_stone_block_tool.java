package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class five_compressed_black_stone_block_tool implements ToolMaterial {

    public static final five_compressed_black_stone_block_tool INSTANCE = new five_compressed_black_stone_block_tool();

    @Override
    public int getDurability() {
        return 5999999;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 32767.0F;
    }

    @Override
    public float getAttackDamage() {
        return 2048.0F;
    }

    @Override
    public int getMiningLevel() {
        return 99;
    }

    @Override
    public int getEnchantability() {
        return 5120;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.FBB_BLOCK);
    }
}