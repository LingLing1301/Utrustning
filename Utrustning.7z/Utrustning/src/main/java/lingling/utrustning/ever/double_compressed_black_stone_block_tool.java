package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class double_compressed_black_stone_block_tool implements ToolMaterial {

    public static final double_compressed_black_stone_block_tool INSTANCE = new double_compressed_black_stone_block_tool();

    @Override
    public int getDurability() {
        return 65535;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 255.0F;
    }

    @Override
    public float getAttackDamage() {
        return 63.0F;
    }

    @Override
    public int getMiningLevel() {
        return 19;
    }

    @Override
    public int getEnchantability() {
        return 365;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.DBB_BLOCK);
    }
}