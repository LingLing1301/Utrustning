package lingling.utrustning.ever;

import net.minecraft.block.*;
import net.minecraft.item.Item;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.Random;

public class sixfold_compressed_black_stone_block extends Block {
    protected sixfold_compressed_black_stone_block(AbstractBlock.Settings settings) {
        super(settings);
    }
    @Override
    public boolean emitsRedstonePower(BlockState state) {
        return true;
    }
    @Override
    public int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {return 15;}

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        super.randomDisplayTick(state, world, pos, random);
        for (int i = -2; i <= 2; ++i) {
            block1:
            for (int j = -2; j <= 2; ++j) {
                if (i > -2 && i < 2 && j == -1) {
                    j = 2;
                }
                for (int k = 0; k <= 1; ++k) {
                    world.addParticle(ParticleTypes.ENCHANT, (double) pos.getX() + 0.5, (double) pos.getY() + 2.0, (double) pos.getZ() + 0.5, (double) ((float) i + random.nextFloat()) - 0.5, (float) k - random.nextFloat() - 1.0f, (double) ((float) j + random.nextFloat()) - 0.5);
                }
            }
        }
    }
}


