package lingling.utrustning.ever;

import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.Random;

public class sevenfold_compressed_black_stone_block extends Block {
    protected sevenfold_compressed_black_stone_block(AbstractBlock.Settings settings) {
        super(settings);
    }
    @Override
    public boolean emitsRedstonePower(BlockState state) {
        return true;
    }
    @Override
    public int getWeakRedstonePower(BlockState state, BlockView world, BlockPos pos, Direction direction) {return 15;}

    @Override
    public void randomDisplayTick(BlockState state, World world, BlockPos pos, Random random) {
        super.randomDisplayTick(state, world, pos, random);
        for (int i = -2; i <= 2; ++i) {
            block1:
            for (int j = -2; j <= 2; ++j) {
                if (i > -2 && i < 2 && j == -1) {
                    j = 2;
                }
                for (int k = 0; k <= 1; ++k) {
                    world.addParticle(ParticleTypes.LAVA, (double) pos.getX() + 0.65, (double) pos.getY() + 2.0, (double) pos.getZ() + 0.65, (double) ((float) i + random.nextFloat()) - 0.65, (float) k - random.nextFloat() - 1.0f, (double) ((float) j + random.nextFloat()) - 0.65);
                }
            }
        }
    }
}


