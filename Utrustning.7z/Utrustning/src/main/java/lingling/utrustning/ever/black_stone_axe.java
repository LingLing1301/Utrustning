package lingling.utrustning.ever;

import net.minecraft.item.AxeItem;
import net.minecraft.item.ToolMaterial;

public class black_stone_axe extends AxeItem {
    protected black_stone_axe(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
}
