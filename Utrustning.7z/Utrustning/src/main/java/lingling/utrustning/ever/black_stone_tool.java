package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class black_stone_tool implements ToolMaterial {

    public static final black_stone_tool INSTANCE = new black_stone_tool();

    @Override
    public int getDurability() {
        return 2435;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 15.0F;
    }

    @Override
    public float getAttackDamage() {
        return 1.0F;
    }

    @Override
    public int getMiningLevel() {
        return 4;
    }

    @Override
    public int getEnchantability() {
        return 35;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.BS);
    }
}
