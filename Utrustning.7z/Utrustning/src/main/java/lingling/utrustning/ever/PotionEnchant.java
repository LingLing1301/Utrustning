package lingling.utrustning.ever;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

import static net.minecraft.enchantment.Enchantment.*;
import static net.minecraft.enchantment.EnchantmentTarget.*;
import static net.minecraft.entity.EquipmentSlot.*;

public class PotionEnchant extends Enchantment {
    public PotionEnchant() {
        super(Rarity.UNCOMMON, WEAPON, new EquipmentSlot[] {MAINHAND});
    }
    @Override
    public int getMinPower(int level) {
        return 13;
    }
    @Override
    public int getMaxLevel() {
        return 3;
    }
    @Override
    public void onTargetDamaged(LivingEntity user, Entity target, int level) {
        if(target instanceof LivingEntity) {
            ((LivingEntity) target).addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 60 * level, level - 1));
        }

        super.onTargetDamaged(user, target, level);
    }

}
