package lingling.utrustning.ever;


import net.minecraft.client.MinecraftClient;

public enum FFFClient {
    INSTANCE;
    private EventManger eventManger;
    private Hlist hax;
    private boolean enabled = true;
    public static final MinecraftClient MC = MinecraftClient.getInstance();

    public Hlist getHax()
    {
        return hax;
    }
    public EventManger getEventManger()
    {
        return eventManger;
    }
    public boolean isEnabled()
    {
        return enabled;
    }
    public void initialize() {
        eventManger = new EventManger(this);
    }
    }
