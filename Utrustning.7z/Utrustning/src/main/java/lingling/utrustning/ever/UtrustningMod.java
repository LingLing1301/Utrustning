package lingling.utrustning.ever;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.*;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.*;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class UtrustningMod implements ModInitializer {
	public static final Item Bs = new Item(new FabricItemSettings());
	public static final ItemGroup BG = FabricItemGroupBuilder.create(
					new Identifier("p", "black_group"))
			.icon(() -> new ItemStack(Bs))
			.build();
	private static Enchantment POISON = Registry.register(
			Registry.ENCHANTMENT,
			new Identifier("p", "poison"),
			new PotionEnchant()
	);
	public static final black_stone BS = new black_stone(new FabricItemSettings().group(BG));
	public static final OreBlock B_ORE = new OreBlock(FabricBlockSettings.of(Material.STONE).strength(19.0F,25.0F));
	public static final Block B_BLOCK = new Block(FabricBlockSettings.of(Material.STONE).strength(23.0F,43.0F));
	public static final Block BB_BLOCK = new Block(FabricBlockSettings.of(Material.STONE).strength(100.0F,150.0F));
	public static final Block DBB_BLOCK = new Block(FabricBlockSettings.of(Material.STONE).strength(350.0F,550.0F).luminance(1));
	public static final Block TBB_BLOCK = new Block(FabricBlockSettings.of(Material.STONE).strength(1000.0F,1850.0F).luminance(3));
	public static final Block QBB_BLOCK = new Block(FabricBlockSettings.of(Material.METAL).strength(4500.0F,8000.0F).luminance(5));
	public static final five_compressed_black_stone_block FBB_BLOCK = new five_compressed_black_stone_block(FabricBlockSettings.of(Material.METAL).strength(13500.0F,25000.0F).luminance(7));
	public static final sixfold_compressed_black_stone_block SBB_BLOCK = new sixfold_compressed_black_stone_block(FabricBlockSettings.of(Material.METAL).strength(100000.0F,200000.0F).luminance(9));
	public static final sevenfold_compressed_black_stone_block SFB_BLOCK = new sevenfold_compressed_black_stone_block(FabricBlockSettings.of(Material.METAL).strength(900000.0F,404000.0F).luminance(11));
	public static ToolItem BS_S = new ShovelItem(black_stone_tool.INSTANCE, 5.5F, -2.8F, new Item.Settings().group(BG));
	public static ToolItem BS_W = new SwordItem(black_stone_tool.INSTANCE, 7, -2.2F, new Item.Settings().group(BG));
	public static ToolItem BS_P = new black_stone_pickaxe(black_stone_tool.INSTANCE, 5, -2.6F, new Item.Settings().group(BG));
	public static ToolItem BS_A = new black_stone_axe(black_stone_tool.INSTANCE, 9.0F, -2.8F, new Item.Settings().group(BG));
	public static ToolItem BS_H = new black_stone_hoe(black_stone_tool.INSTANCE, 0, 0.2F, new Item.Settings().group(BG));
	public static BowItem BBOW = new black_stone_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(black_stone_tool.INSTANCE.getDurability()));

	public static ToolItem BB_S = new ShovelItem(black_block_tool.INSTANCE, 7.5F, -2.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BB_W = new SwordItem(black_block_tool.INSTANCE, 9, -1.8F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BB_P = new black_stone_pickaxe(black_block_tool.INSTANCE, 7, -2.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BB_A = new black_stone_axe(black_block_tool.INSTANCE, 11.0F, -2.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BB_H = new black_stone_hoe(black_block_tool.INSTANCE, 2, 0.6F, new Item.Settings().group(BG).fireproof());
	public static BowItem BBBOW = new black_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(black_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem BBB_S = new compression_black_block_shovel(compression_black_block_tool.INSTANCE, 9.5F, -1.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BBB_W = new compression_black_block_sword(compression_black_block_tool.INSTANCE, 11, -0.8F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BBB_P = new compression_black_block_pickaxe(compression_black_block_tool.INSTANCE, 9, -1.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BBB_A = new compression_black_block_axe(compression_black_block_tool.INSTANCE, 13.0F, -1.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem BBB_H = new compression_black_block_hoe(compression_black_block_tool.INSTANCE, 4, 1.6F, new Item.Settings().group(BG).fireproof());
	public static BowItem BBBBOW = new compression_black_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(compression_black_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem DBBB_S = new double_compressed_black_stone_block_shovel(double_compressed_black_stone_block_tool.INSTANCE, 12.5F, 0.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem DBBB_W = new double_compressed_black_stone_block_sword(double_compressed_black_stone_block_tool.INSTANCE, 14, 0.7F, new Item.Settings().group(BG).fireproof());
	public static ToolItem DBBB_P = new double_compressed_black_stone_block_pickaxe(double_compressed_black_stone_block_tool.INSTANCE, 12, 0.3F, new Item.Settings().group(BG).fireproof());
	public static ToolItem DBBB_A = new double_compressed_black_stone_block_axe(double_compressed_black_stone_block_tool.INSTANCE, 16.0F, 0.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem DBBB_H = new double_compressed_black_stone_block_hoe(double_compressed_black_stone_block_tool.INSTANCE, 7, 3.1F, new Item.Settings().group(BG).fireproof());
	public static BowItem DBBBBOW = new double_compressed_black_stone_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(double_compressed_black_stone_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem TBBB_S = new triple_compressed_black_stone_block_shovel(triple_compressed_black_stone_block_tool.INSTANCE, 22.5F, 10.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem TBBB_W = new triple_compressed_black_stone_block_sword(triple_compressed_black_stone_block_tool.INSTANCE, 24, 10.7F, new Item.Settings().group(BG).fireproof());
	public static ToolItem TBBB_P = new triple_compressed_black_stone_block_pickaxe(triple_compressed_black_stone_block_tool.INSTANCE, 22, 10.3F, new Item.Settings().group(BG).fireproof());
	public static ToolItem TBBB_A = new triple_compressed_black_stone_block_axe(triple_compressed_black_stone_block_tool.INSTANCE, 26.0F, 10.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem TBBB_H = new triple_compressed_black_stone_block_hoe(triple_compressed_black_stone_block_tool.INSTANCE, 17, 13.1F, new Item.Settings().group(BG).fireproof());
	public static BowItem TBBBBOW = new triple_compressed_black_stone_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(triple_compressed_black_stone_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem QBBB_S = new quadruple_compressed_black_stone_block_shovel(quadruple_compressed_black_stone_block_tool.INSTANCE, 42.5F, 30.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem QBBB_W = new quadruple_compressed_black_stone_block_sword(quadruple_compressed_black_stone_block_tool.INSTANCE, 44, 30.7F, new Item.Settings().group(BG).fireproof());
	public static ToolItem QBBB_P = new quadruple_compressed_black_stone_block_pickaxe(quadruple_compressed_black_stone_block_tool.INSTANCE, 42, 30.3F, new Item.Settings().group(BG).fireproof());
	public static ToolItem QBBB_A = new quadruple_compressed_black_stone_block_axe(quadruple_compressed_black_stone_block_tool.INSTANCE, 46.0F, 30.1F, new Item.Settings().group(BG).fireproof());
	public static ToolItem QBBB_H = new quadruple_compressed_black_stone_block_hoe(quadruple_compressed_black_stone_block_tool.INSTANCE, 37, 33.1F, new Item.Settings().group(BG).fireproof());
	public static BowItem QBBBBOW = new quadruple_compressed_black_stone_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(quadruple_compressed_black_stone_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem FBBB_S = new five_compressed_black_stone_block_shovel(five_compressed_black_stone_block_tool.INSTANCE, 142.5F, 60.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem FBBB_W = new five_compressed_black_stone_block_sword(five_compressed_black_stone_block_tool.INSTANCE, 144, 61.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem FBBB_P = new five_compressed_black_stone_block_pickaxe(five_compressed_black_stone_block_tool.INSTANCE, 142, 60.6F, new Item.Settings().group(BG).fireproof());
	public static ToolItem FBBB_A = new five_compressed_black_stone_block_axe(five_compressed_black_stone_block_tool.INSTANCE, 146.0F, 60.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem FBBB_H = new five_compressed_black_stone_block_hoe(five_compressed_black_stone_block_tool.INSTANCE, 137, 66.2F, new Item.Settings().group(BG).fireproof());
	public static BowItem FBBBBOW = new five_compressed_black_stone_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(five_compressed_black_stone_block_tool.INSTANCE.getDurability()).fireproof());

	public static ToolItem SBBB_S = new sixfold_compressed_black_stone_block_shovel(sixfold_compressed_black_stone_block_tool.INSTANCE, 1142.5F, 160.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem SBBB_W = new sixfold_compressed_black_stone_block_sword(sixfold_compressed_black_stone_block_tool.INSTANCE, 1144, 161.4F, new Item.Settings().group(BG).fireproof());
	public static ToolItem SBBB_P = new sixfold_compressed_black_stone_block_pickaxe(sixfold_compressed_black_stone_block_tool.INSTANCE, 1142, 160.6F, new Item.Settings().group(BG).fireproof());
	public static ToolItem SBBB_A = new sixfold_compressed_black_stone_block_axe(sixfold_compressed_black_stone_block_tool.INSTANCE, 1146.0F, 160.2F, new Item.Settings().group(BG).fireproof());
	public static ToolItem SBBB_H = new sixfold_compressed_black_stone_block_hoe(sixfold_compressed_black_stone_block_tool.INSTANCE, 1137, 166.2F, new Item.Settings().group(BG).fireproof());
	public static BowItem SBBBBOW = new sixfold_compressed_black_stone_block_bow(new FabricItemSettings().group(BG).maxCount(1).maxDamage(sixfold_compressed_black_stone_block_tool.INSTANCE.getDurability()).fireproof());

	@Override
	public void onInitialize() {
		RegItem.register();
		Registry.register(Registry.BLOCK, new Identifier("p", "black_stone_ore"), B_ORE);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_ore"), new BlockItem(B_ORE, new FabricItemSettings().group(BG)));
		Registry.register(Registry.BLOCK, new Identifier("p", "black_stone_block"), B_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_block"), new BlockItem(B_BLOCK, new FabricItemSettings().group(BG).fireproof()));
		Registry.register(Registry.BLOCK, new Identifier("p", "compression_black_block"), BB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block"), new BlockItem(BB_BLOCK, new FabricItemSettings().group(BG).fireproof()));
		Registry.register(Registry.BLOCK, new Identifier("p", "double_compressed_black_stone_block"), DBB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block"), new BlockItem(DBB_BLOCK, new FabricItemSettings().group(BG).fireproof()));
		Registry.register(Registry.BLOCK, new Identifier("p", "triple_compressed_black_stone_block"), TBB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block"), new BlockItem(TBB_BLOCK, new FabricItemSettings().group(BG).fireproof()));
		Registry.register(Registry.BLOCK, new Identifier("p", "quadruple_compressed_black_stone_block"), QBB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block"), new BlockItem(QBB_BLOCK, new FabricItemSettings().group(BG).fireproof().maxCount(32)));
		Registry.register(Registry.BLOCK, new Identifier("p", "five_compressed_black_stone_block"), FBB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block"), new five_compressed_black_stone_block_item(FBB_BLOCK, new FabricItemSettings().group(BG).fireproof().maxCount(32)));
		Registry.register(Registry.BLOCK, new Identifier("p", "sixfold_compressed_black_stone_block"), SBB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block"), new sixfold_compressed_black_stone_block_item(SBB_BLOCK, new FabricItemSettings().group(BG).fireproof().maxCount(32)));
		Registry.register(Registry.BLOCK, new Identifier("p", "sevenfold_compressed_black_stone_block"), SFB_BLOCK);
		Registry.register(Registry.ITEM, new Identifier("p", "sevenfold_compressed_black_stone_block"), new sevenfold_compressed_black_stone_block_item(SFB_BLOCK, new FabricItemSettings().group(BG).fireproof().maxCount(16)));
		Registry.register(Registry.ITEM, new Identifier("p", "bs"), Bs);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone"), BS);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_shovel"), BS_S);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_sword"), BS_W);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_pickaxe"), BS_P);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_axe"), BS_A);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_hoe"), BS_H);
		Registry.register(Registry.ITEM, new Identifier("p", "black_stone_bow"), BBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "black_block_shovel"), BB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "black_block_sword"), BB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "black_block_pickaxe"), BB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "black_block_axe"), BB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "black_block_hoe"), BB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "black_block_bow"), BBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_shovel"), BBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_sword"), BBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_pickaxe"), BBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_axe"), BBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_hoe"), BBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "compression_black_block_bow"), BBBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_shovel"), DBBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_sword"), DBBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_pickaxe"), DBBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_axe"), DBBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_hoe"), DBBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "double_compressed_black_stone_block_bow"), DBBBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_shovel"), TBBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_sword"), TBBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_pickaxe"), TBBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_axe"), TBBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_hoe"), TBBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "triple_compressed_black_stone_block_bow"), TBBBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_shovel"), QBBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_sword"), QBBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_pickaxe"), QBBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_axe"), QBBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_hoe"), QBBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "quadruple_compressed_black_stone_block_bow"), QBBBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_shovel"), FBBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_sword"), FBBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_pickaxe"), FBBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_axe"), FBBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_hoe"), FBBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "five_compressed_black_stone_block_bow"), FBBBBOW);

		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_shovel"), SBBB_S);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_sword"), SBBB_W);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_pickaxe"),SBBB_P);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_axe"), SBBB_A);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_hoe"), SBBB_H);
		Registry.register(Registry.ITEM, new Identifier("p", "sixfold_compressed_black_stone_block_bow"), SBBBBOW);
	}
}
