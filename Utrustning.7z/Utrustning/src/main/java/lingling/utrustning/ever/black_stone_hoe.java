package lingling.utrustning.ever;

import net.minecraft.item.HoeItem;
import net.minecraft.item.ToolMaterial;

public class black_stone_hoe extends HoeItem {

    protected black_stone_hoe(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
}
