package lingling.utrustning.ever;

import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class compression_black_block_tool implements ToolMaterial {

    public static final compression_black_block_tool INSTANCE = new compression_black_block_tool();

    @Override
    public int getDurability() {
        return 32767;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 127.0F;
    }

    @Override
    public float getAttackDamage() {
        return 12.0F;
    }

    @Override
    public int getMiningLevel() {
        return 13;
    }

    @Override
    public int getEnchantability() {
        return 165;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(UtrustningMod.BB_BLOCK);
    }
}